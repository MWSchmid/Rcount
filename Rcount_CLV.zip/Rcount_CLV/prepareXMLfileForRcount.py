import sys

usage = """

python %s annotationXML readsInfile readsOutfile countTableFile sampleName useMulti useStrand minReads maxDist minBelowMaxDist

useMulti and useStrand should be 'true' or 'false' (without the quotes)

""" % sys.argv[0]

if len(sys.argv) < 11:
	sys.exit(usage)

annoXML = sys.argv[1]
readsInfile = sys.argv[2]
readsOutfile = sys.argv[3]
countTableFile = sys.argv[4]
sampleName = sys.argv[5]
useMulti = sys.argv[6]
useStrand = sys.argv[7]
minReads = int(sys.argv[8])
maxDist = int(sys.argv[9])
minBelowMaxDist = int(sys.argv[10])

blankXML = '''<?xml version="1.0" encoding="UTF-8"?>
<p502project version="1.0">
    <name entry="%s">
        <files entry="">
            <dataBaseInfile entry="%s"/>
            <dataBaseOutfile entry=""/>
            <readsInfile entry="%s"/>
            <readsOutfile entry="%s"/>
            <countTableFile entry="%s"/>
        </files>
        <parameters entry="">
            <multi entry="%s"/>
            <stranded entry="%s"/>
            <minReads entry="%d"/>
            <maxDist entry="%d"/>
            <minBelowMaxDist entry="%d"/>
        </parameters>
        <region entry="">
            <useRegion entry="false"/>
            <regionStartName entry=""/>
            <regionStart entry="0"/>
            <regionEndName entry=""/>
            <regionEnd entry="0"/>
        </region>
        <settings entry="">
            <indexStepSize entry="10000"/>
            <bufferSizeBAM entry="200000"/>
            <bufferSizeMAP entry="200000"/>
            <bufferSizeOUT entry="200000"/>
        </settings>
    </name>
</p502project>
''' % (sampleName,annoXML,readsInfile,readsOutfile,countTableFile, useMulti, useStrand, minReads, maxDist, minBelowMaxDist)

print blankXML